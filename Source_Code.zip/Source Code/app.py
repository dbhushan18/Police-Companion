import os, sys, shutil, time

from flask import Flask, request, jsonify, render_template,send_from_directory
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
import numpy as np
import urllib.request
import json
from geopy.geocoders import Nominatim
import pickle
import folium

app = Flask(__name__)



@app.route('/')
def root():
    return render_template('index.html')

@app.route('/result.html', methods = ['POST'])
def predict():
    rfc = joblib.load('model/rf_model')
    print('model loaded')

    if request.method == 'POST':

        address = request.form['Location']
        geolocator = Nominatim(user_agent='app')
        location = geolocator.geocode(address,timeout=None)
        print(location.address)
        lat=[location.latitude]
        log=[location.longitude]
        latlong=pd.DataFrame({'latitude':lat,'longitude':log})
        print(latlong)

        DT= request.form['timestamp']
        latlong['timestamp']=DT
        data=latlong
        cols = data.columns.tolist()
        cols = cols[-1:] + cols[:-1]
        data = data[cols]

        data['timestamp'] = pd.to_datetime(data['timestamp'].astype(str), errors='coerce')
        data['timestamp'] = pd.to_datetime(data['timestamp'], format = '%d/%m/%Y %H:%M:%S')
        column_1 = data.iloc[:,0]
        DT=pd.DataFrame({"year": column_1.dt.year,
              "month": column_1.dt.month,
              "day": column_1.dt.day,
              "hour": column_1.dt.hour,
              "dayofyear": column_1.dt.dayofyear,
              "week": column_1.dt.week,
              "weekofyear": column_1.dt.weekofyear,
              "dayofweek": column_1.dt.dayofweek,
              "weekday": column_1.dt.weekday,
              "quarter": column_1.dt.quarter,
             })
        data=data.drop('timestamp',axis=1)
        final=pd.concat([DT,data],axis=1)
        X=final.iloc[:,[1,2,3,4,6,10,11]].values
        my_prediction = rfc.predict(X)
        if my_prediction[0][0] == 1:
            my_prediction='Predicted type of crime : Robbery-Act 379'
        elif my_prediction[0][1] == 1:
            my_prediction='Predicted type of crime : Gambling-Act 13'
        elif my_prediction[0][2] == 1:
            my_prediction='Predicted type of crime : Accident-Act 279'
        elif my_prediction[0][3] == 1:
            my_prediction='Predicted type of crime : Violence-Act 323'
        elif my_prediction[0][4] == 1:
            my_prediction='Predicted type of crime : Murder-Act 302'
        elif my_prediction[0][5] == 1:
            my_prediction='Predicted type of crime : kidnapping-Act 363'
        else:
            my_prediction='Place is safe no crime expected at that timestamp.'



    return render_template('result.html', prediction = my_prediction)
@app.route('/result2.html', methods = ['POST'])
def pred_loc():
    loaded_model = pickle.load(open("model/dt_model.pkl","rb"))
    print("Model loaded")
    if request.method == 'POST':
        ty = request.form['crime']
        g=0
        k=0
        m=0
        r=0
        dv=0
        a=0
        if ty == 'G':
            g = 1
        elif ty == 'K':
            k = 1
        elif ty == 'M':
            m = 1
        elif ty == 'R' :
            r =1
        elif ty == 'DV' :
            dv = 1
        else :
            a = 1
        ls = [r,g,a,dv,m,k]
        print(ls)
    #latlong=pd.DataFrame({'latitude':lat,'longitude':log})
        DATA = pd.DataFrame({'R':r,'G':g,'A':a,'DV':dv,'M':m,'K':k},index=[0])
        DT= request.form['timestamp']
        DATA['timestamp']=DT
        data=DATA
        cols = data.columns.tolist()
        cols = cols[-1:] + cols[:-1]
        data = data[cols]

        data['timestamp'] = pd.to_datetime(data['timestamp'].astype(str), errors='coerce')
        data['timestamp'] = pd.to_datetime(data['timestamp'], format = '%d/%m/%Y %H:%M:%S')
        column_1 = data.iloc[:,0]
        DT=pd.DataFrame({"year": column_1.dt.year,
                "month": column_1.dt.month,
                "day": column_1.dt.day,
                "hour": column_1.dt.hour,
                "dayofyear": column_1.dt.dayofyear,
                "week": column_1.dt.week,
                "weekofyear": column_1.dt.weekofyear,
                "dayofweek": column_1.dt.dayofweek,
                "weekday": column_1.dt.weekday,
                "quarter": column_1.dt.quarter,
                })
        data=data.drop('timestamp',axis=1)
        final=pd.concat([DT,data],axis=1)
        X=final.iloc[:,[1,2,3,4,6,10,11,12,13,14,15]].values
        result = loaded_model.predict(X)
        print(result)
        start_coord = (result[0][0],result[0][1])
        folium_map = folium.Map(location= start_coord,zoom_start=16)
        folium.CircleMarker(
                location=[result[0][0], result[0][1]],
                radius=50,
                popup="Predicted Location",
                color="red",
                fill=True,
                fill_color="#3186cc",
                ).add_to(folium_map)
    return folium_map._repr_html_()
if __name__ == '__main__':
    app.run(debug = True)
